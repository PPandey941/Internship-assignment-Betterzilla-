export default {
    CHAT: 'chat',
    USER: 'user',
    TEMP: 'temp'
}